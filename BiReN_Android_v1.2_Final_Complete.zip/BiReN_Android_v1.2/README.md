# BiReN Android v1.2

BiReN is a local-first personal money and budget planner.

## Final budget model
- 5 editable accounts.
- Monthly income stored by month/year.
- 11 editable categories A-K.
- Category names and allocation percentages are editable.
- Default allocation is 9.09% each; saved allocations must total 100%.
- Monthly income is automatically distributed by the saved allocation percentages.
- Allocation settings continue into later months until changed.
- Category carry-forward: prior remaining + new allocation - current spending.
- Remaining never displays below ₹0.
- Overspending is shown separately and highlighted red.
- Budget/Spent/Remaining/Overspent are shown for every category and month.
- Transfers between the five accounts are supported and are excluded from income/expense totals.
- Income, expenses and transfers are saved locally.

## Build
Use Android Studio or the included GitHub Actions workflow. The GitHub workflow builds `app-debug.apk` from this project.
